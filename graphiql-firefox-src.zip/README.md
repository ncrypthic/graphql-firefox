# Build & Running

1. Install nodejs
2. Install yarn `npm -g install yarn`
3. Install deps `yarn install`
4. Build the source `yarn run build`
5. Open up `index.html` in browser OR start development using `yarn run develop`
